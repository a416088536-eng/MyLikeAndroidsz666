package com.example.mylikeandroid

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader

data class LikeItem(
    val id: String,
    val title: String,
    val author: String,
    val url: String,
    val type: String = "视频",
    val date: String = ""
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MyLikeApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyLikeApp() {
    val context = LocalContext.current
    var likedItems by remember { mutableStateOf(listOf<LikeItem>()) }
    var search by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf(setOf<String>()) }
    var typeFilter by remember { mutableStateOf("全部") }
    var message by remember { mutableStateOf("") }
    var showUnlikeInfo by remember { mutableStateOf(false) }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val text = context.contentResolver.openInputStream(uri)?.use { input ->
                    BufferedReader(InputStreamReader(input)).readText()
                } ?: ""
                val arr = JSONArray(text)
                val parsed = mutableListOf<LikeItem>()
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    parsed += LikeItem(
                        id = o.optString("id", o.optString("aweme_id", "item_$i")),
                        title = o.optString("title", o.optString("desc", "未命名作品")),
                        author = o.optString("author", o.optString("nickname", "")),
                        url = o.optString("url", o.optString("share_url", "")),
                        type = o.optString("type", "视频"),
                        date = o.optString("date", o.optString("create_time", ""))
                    )
                }
                likedItems = parsed.distinctBy { it.id }
                selected = emptySet()
                message = "已导入 ${likedItems.size} 条记录"
            } catch (e: Exception) {
                message = "导入失败：请使用 JSON 数组文件（字段可含 id、title、author、url、type、date）"
            }
        }
    }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val exportItems = likedItems.filter { selected.isEmpty() || it.id in selected }
                val arr = JSONArray()
                exportItems.forEach { item ->
                    arr.put(JSONObject().apply {
                        put("id", item.id); put("title", item.title); put("author", item.author)
                        put("url", item.url); put("type", item.type); put("date", item.date)
                    })
                }
                context.contentResolver.openOutputStream(uri)?.use { it.write(arr.toString(2).toByteArray()) }
                message = "已导出 ${exportItems.size} 条记录"
            } catch (e: Exception) { message = "导出失败" }
        }
    }

    val visibleItems = likedItems.filter { item ->
        (typeFilter == "全部" || item.type.contains(typeFilter, ignoreCase = true)) &&
        (search.isBlank() || item.title.contains(search, true) ||
            item.author.contains(search, true) || item.date.contains(search, true))
    }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(title = {
                    Column {
                        Text("MyLike 安卓版", fontWeight = FontWeight.Bold)
                        Text("本地点赞列表管理 · 0.1.0", style = MaterialTheme.typography.labelSmall)
                    }
                })
            }
        ) { padding ->
            Column(
                modifier = Modifier.padding(padding).fillMaxSize().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { importLauncher.launch(arrayOf("application/json", "text/*")) }) {
                        Text("导入列表")
                    }
                    OutlinedButton(onClick = {
                        selected = if (selected.size == visibleItems.size) emptySet()
                                   else visibleItems.map { it.id }.toSet()
                    }) { Text("全选/取消") }
                    OutlinedButton(onClick = { exportLauncher.launch("mylike-export.json") }) {
                        Text("导出")
                    }
                }
                OutlinedTextField(
                    value = search, onValueChange = { search = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("搜索标题、作者或日期") },
                    singleLine = true
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("全部", "视频", "图集").forEach { filter ->
                        FilterChip(
                            selected = typeFilter == filter,
                            onClick = { typeFilter = filter },
                            label = { Text(filter) }
                        )
                    }
                    Spacer(Modifier.weight(1f))
                    Text("${visibleItems.size} 条", modifier = Modifier.align(Alignment.CenterVertically))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        enabled = visibleItems.any { it.url.isNotBlank() },
                        onClick = {
                            val candidates = visibleItems.filter { it.url.isNotBlank() }.shuffled()
                            if (candidates.isNotEmpty()) {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(candidates.first().url))
                                try { context.startActivity(intent) }
                                catch (_: Exception) { message = "无法打开该作品链接" }
                            }
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("随机打开一条") }
                    OutlinedButton(
                        enabled = selected.isNotEmpty(),
                        onClick = { showUnlikeInfo = true },
                        modifier = Modifier.weight(1f)
                    ) { Text("取消点赞（待接入）") }
                }
                if (message.isNotBlank()) {
                    Text(message, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                }
                if (likedItems.isEmpty()) {
                    Spacer(Modifier.height(24.dp))
                    Text("先导入你的点赞记录 JSON 文件。", style = MaterialTheme.typography.titleMedium)
                    Text("此版本先完成本地列表管理；尚未连接抖音账号，也不会自动取消线上点赞。")
                } else if (visibleItems.isEmpty()) {
                    Text("没有匹配的作品。")
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(visibleItems, key = { it.id }) { item ->
                            Card(modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Checkbox(
                                        checked = item.id in selected,
                                        onCheckedChange = { checked ->
                                            selected = if (checked) selected + item.id else selected - item.id
                                        }
                                    )
                                    Column(
                                        modifier = Modifier.weight(1f).clickable {
                                            if (item.url.isNotBlank()) {
                                                try { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(item.url))) }
                                                catch (_: Exception) { message = "无法打开作品链接" }
                                            }
                                        }
                                    ) {
                                        Text(item.title.ifBlank { "未命名作品" }, fontWeight = FontWeight.SemiBold)
                                        Text(
                                            listOf(item.author, item.type, item.date).filter { it.isNotBlank() }.joinToString(" · "),
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (showUnlikeInfo) {
            AlertDialog(
                onDismissRequest = { showUnlikeInfo = false },
                title = { Text("批量取消点赞尚未接入") },
                text = {
                    Text("当前版本只保存和整理本地记录。要安全地取消抖音账号中的真实点赞，需要进一步验证可用的授权/交互方式；此按钮不会偷偷执行操作，也不会请求你的密码或验证码。")
                },
                confirmButton = {
                    TextButton(onClick = { showUnlikeInfo = false }) { Text("知道了") }
                }
            )
        }
    }
}
