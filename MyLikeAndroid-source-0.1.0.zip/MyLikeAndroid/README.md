# MyLike 安卓版（基础工程 0.1.0）

这是一个可在 Android Studio 中打开的原生 Kotlin + Jetpack Compose 工程起点。

## 当前已实现
- 导入 JSON 格式的本地点赞列表
- 标题、作者、日期搜索
- 全部 / 视频 / 图集筛选
- 多选、导出 JSON
- 随机打开一条作品链接
- 本地列表 UI

## 当前未实现
- 尚未登录或连接抖音
- 尚未读取抖音账号的真实点赞列表
- “批量取消点赞”按钮目前只展示说明，不会修改抖音账号中的点赞状态
- 暂未实现视频内嵌播放、封面抓取、收藏夹同步

## JSON 数据格式示例
[
  {
    "id": "123456",
    "title": "作品标题",
    "author": "作者昵称",
    "url": "https://www.douyin.com/video/123456",
    "type": "视频",
    "date": "2025-01-01"
  }
]

也兼容常见字段别名：aweme_id、desc、nickname、share_url、create_time。

## 构建 APK
1. 在电脑安装 Android Studio（JDK/Android SDK 按向导安装）。
2. 解压本工程，在 Android Studio 选择 Open，打开 `MyLikeAndroid` 文件夹。
3. 等待 Gradle Sync 完成。
4. 选择 Build > Build Bundle(s) / APK(s) > Build APK(s)。
5. APK 通常生成在 `app/build/outputs/apk/debug/app-debug.apk`。
6. 把 APK 传到安卓手机，在系统提示下允许该来源安装应用，再安装。

如果没有电脑，可以把工程上传到自己的 GitHub 仓库，再配置 GitHub Actions 云端构建；这需要额外加入构建工作流，不能仅凭手机上的普通文件管理器直接生成 APK。

## 重要说明
MyLike 原项目是 Windows 桌面应用；安卓端需要重新开发，不能直接把 Windows EXE 转成 APK。
抖音官方开放接口并不等同于“读取用户所有点赞过的视频并批量取消点赞”的通用接口。后续必须单独验证账号授权和可用交互方式，不能承诺私有接口长期可用，也不应绕过验证码、限流或平台安全控制。
